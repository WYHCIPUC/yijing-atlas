// Prepared for manual review. This helper has not been executed or used to package evidence.
// Usage: node this-file.mjs --summary FINAL_SUMMARY.json --source SOURCE_SNAPSHOT.json --out NEW.zip --root REPOSITORY
// Built-in Node modules only. No browser, server, Git operation, profile access, deletion, or overwrite.
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { existsSync, readFileSync, realpathSync, statSync, writeFileSync } from 'node:fs';
import { basename, dirname, isAbsolute, relative, resolve, sep } from 'node:path';
import { fileURLToPath } from 'node:url';
import { deflateRawSync } from 'node:zlib';

const options = {};
const args = process.argv.slice(2);
for (let index = 0; index < args.length; index += 2) {
  const key = args[index];
  assert.ok(['--summary', '--source', '--out', '--root'].includes(key), `Unknown option: ${key}`);
  assert.ok(args[index + 1] && !args[index + 1].startsWith('--'), `Missing value: ${key}`);
  assert.equal(options[key], undefined, `Duplicate option: ${key}`);
  options[key] = args[index + 1];
}
for (const key of ['--summary', '--source', '--out', '--root']) assert.ok(options[key], `Required: ${key}`);

const root = realpathSync(resolve(options['--root']));
const evidenceRoot = realpathSync(resolve(root, 'docs/development/evidence'));
const inputRoot = realpathSync(resolve(evidenceRoot, '2026-10-25-learning-feedback-input'));
const slash = value => value.split(sep).join('/');
const hash = data => createHash('sha256').update(data).digest('hex');
function within(base, target) {
  const path = relative(base, target);
  assert.ok(path && !isAbsolute(path) && path !== '..' && !path.startsWith(`..${sep}`), `Path outside allowed directory: ${target}`);
  return target;
}
function inputFile(path, base = evidenceRoot) {
  const full = realpathSync(isAbsolute(path) ? path : resolve(root, path));
  within(base, full);
  assert.ok(statSync(full).isFile(), `Expected file: ${full}`);
  return full;
}
const summaryPath = inputFile(options['--summary']);
const sourcePath = inputFile(options['--source']);
const summaryBytes = readFileSync(summaryPath);
const sourceBytes = readFileSync(sourcePath);
const rows = JSON.parse(summaryBytes);
const snapshot = JSON.parse(sourceBytes);
assert.ok(Array.isArray(rows), 'Final summary must be the batch row array, including retained failed attempts.');
assert.ok(Array.isArray(snapshot.files), 'Source snapshot must contain a files array.');
const snapshotHashes = new Map();
for (const entry of snapshot.files) {
  assert.ok(typeof entry.path === 'string' && /^[0-9a-f]{64}$/.test(entry.sha256), 'Malformed source snapshot entry.');
  assert.equal(snapshotHashes.has(entry.path), false, `Duplicate snapshot path: ${entry.path}`);
  snapshotHashes.set(entry.path, entry.sha256);
}

const scenarioNames = ['review-card-retry', 'review-activity-retry', 'review-achievement-retry', 'review-leave',
  'oral-self-record-retry', 'oral-self-activity-retry', 'oral-ai-save-retry', 'oral-ai-stale-course',
  'oral-ai-stale-edit', 'oral-ai-stale-leave', 'assessment-result', 'assessment-save-retry',
  'quiz-result', 'quiz-save-retry', 'divination-result', 'divination-save-retry',
  'meihua-number-result', 'meihua-number-save-retry', 'meihua-time-result', 'meihua-time-save-retry'];
const representatives = ['quiz-save-retry', 'assessment-save-retry', 'oral-self-record-retry',
  'review-card-retry', 'meihua-number-save-retry'];
const expectedScopes = [...[1440, 390].flatMap(width => scenarioNames.map(name => `${width}-${name}`)),
  '320-quiz-save-retry', ...[1280, 768].flatMap(width => representatives.map(name => `${width}-${name}`))];
assert.equal(expectedScopes.length, 51);
const observedFiles = ['web/index.html', 'web/js/main.js', 'web/js/learning-feedback.js', 'web/js/review-session.js',
  'web/js/review-engine.js', 'web/js/learning-progress.js', 'web/js/learning-review.js', 'web/js/learning-assessment.js',
  'web/js/learning-assessment-page.js', 'web/js/modes/learning-mode.js', 'web/js/modes/review-mode.js',
  'web/js/modes/quiz-mode.js', 'web/js/modes/divination-mode.js', 'web/js/quiz-session.js', 'web/js/quiz-engine.js',
  'web/js/achievement-engine.js', 'web/js/achievement-storage.js', 'web/js/divination-history.js',
  'web/js/meihua-engine.js', 'web/js/divination-interpretation.js', 'web/js/learning-curriculum.js',
  'web/styles/main.css', 'web/styles/immersive.css', 'web/data/hexagrams.json', 'web/data/trigrams.json',
  'web/data/wings.json', 'web/data/theorems.json', 'web/data/almanac-terms.json', 'web/sw.js',
  'scripts/serve.mjs', 'scripts/test-learning-feedback.mjs'];
assert.equal(observedFiles.length, 31);
const expectedPaths = [...observedFiles].sort();
function verifyCurrentSource() {
  for (const path of observedFiles) {
    assert.ok(snapshotHashes.has(path), `Snapshot lacks observed path: ${path}`);
    assert.equal(hash(readFileSync(inputFile(resolve(root, path), root))), snapshotHashes.get(path), `Current source differs: ${path}`);
  }
}
verifyCurrentSource();

const outputPath = resolve(options['--out']);
assert.ok(outputPath.endsWith('.zip'), '--out must name a new .zip file.');
assert.ok(statSync(dirname(outputPath)).isDirectory(), 'Output parent directory must already exist.');
const manifestPath = outputPath.replace(/\.zip$/, '.manifest.json');
const checksumsPath = outputPath.replace(/\.zip$/, '.sha256');
for (const path of [outputPath, manifestPath, checksumsPath]) assert.equal(existsSync(path), false, `Refusing overwrite: ${path}`);

for (const row of rows) assert.ok(row && expectedScopes.includes(row.scope), `Unexpected scope in summary: ${row?.scope}`);
const missing = expectedScopes.filter(scope => !rows.some(row => row.scope === scope && row.exitCode === 0 && row.nativeAbort !== true && typeof row.trace === 'string'));
assert.deepEqual(missing, [], `No successful trace reference for: ${missing.join(', ')}`);

const artifacts = new Map();
const selections = [];
function addArtifact(name, path) {
  assert.ok(!artifacts.has(name), `Duplicate ZIP entry: ${name}`);
  assert.ok(!name.includes('..') && !name.startsWith('/') && !name.includes('\\'), `Unsafe ZIP entry: ${name}`);
  const bytes = readFileSync(path);
  artifacts.set(name, { bytes, source: slash(relative(root, path)), size: bytes.length, sha256: hash(bytes) });
}
addArtifact('metadata/final-summary.json', summaryPath);
addArtifact('metadata/source-snapshot.json', sourcePath);
const selfPath = fileURLToPath(import.meta.url);
const selfBytes = readFileSync(selfPath);
artifacts.set('metadata/collector.mjs', { bytes: selfBytes, source: 'temporary collector supplied for review', size: selfBytes.length, sha256: hash(selfBytes) });

for (const scope of expectedScopes) {
  // The last successful row is the deterministic accepted candidate; previous rows remain in metadata/final-summary.json.
  const candidates = rows.filter(row => row.scope === scope && row.exitCode === 0 && row.nativeAbort !== true && typeof row.trace === 'string');
  const chosen = candidates.at(-1);
  const tracePath = inputFile(chosen.trace, inputRoot);
  assert.equal(basename(tracePath), 'trace.json');
  const trace = JSON.parse(readFileSync(tracePath));
  assert.equal(trace.status, 'passed', `${scope}: trace is not passed`);
  assert.equal(trace.exitCode, 0, `${scope}: trace exitCode`);
  assert.equal(trace.sourceStableDuringRun, true, `${scope}: sourceStableDuringRun`);
  assert.ok(Array.isArray(trace.pageErrors) && trace.pageErrors.length === 0, `${scope}: page errors`);
  assert.ok(trace.scope === scope || trace.scope === 'all', `${scope}: wrong trace scope`);
  assert.ok(Array.isArray(trace.scenarios), `${scope}: missing scenarios`);
  const scenarios = trace.scenarios.filter(item => item.name === scope);
  assert.equal(scenarios.length, 1, `${scope}: expected exactly one matching scenario`);
  const scenario = scenarios[0];
  assert.equal(scenario.status, 'passed', `${scope}: scenario did not pass`);
  for (const field of ['sourceHashes', 'finalSourceHashes']) {
    assert.ok(trace[field] && typeof trace[field] === 'object', `${scope}: missing ${field}`);
    assert.deepEqual(Object.keys(trace[field]).sort(), expectedPaths, `${scope}: ${field} does not contain exactly 31 expected paths`);
    for (const path of observedFiles) assert.equal(trace[field][path], snapshotHashes.get(path), `${scope}: ${field} mismatch at ${path}`);
  }
  const runDirectory = dirname(tracePath);
  const included = [];
  const include = name => {
    const path = inputFile(resolve(runDirectory, name), runDirectory);
    addArtifact(`scopes/${scope}/${name}`, path);
    included.push(name);
  };
  include('trace.json');
  include('run.log');
  const absentServerLogs = [];
  for (const name of ['server-stdout.log', 'server-stderr.log']) {
    if (existsSync(resolve(runDirectory, name))) include(name);
    else absentServerLogs.push(name);
  }
  assert.ok(Array.isArray(scenario.screenshots) && scenario.screenshots.length > 0, `${scope}: no screenshots recorded`);
  for (const name of new Set(scenario.screenshots)) {
    assert.ok(typeof name === 'string' && /^[a-zA-Z0-9][a-zA-Z0-9_.-]*\.png$/.test(name), `${scope}: unsafe screenshot filename`);
    include(name);
  }
  selections.push({ scope, selectedTrace: slash(relative(root, tracePath)), selection: 'last successful summary row',
    successfulRowCount: candidates.length, node: trace.node, uv: trace.uv, browser: trace.browser,
    startedAt: trace.startedAt, finishedAt: trace.finishedAt, status: trace.status, exitCode: trace.exitCode,
    sourceStableDuringRun: true, observedFileCount: 31, pageErrorCount: 0,
    screenshotCount: new Set(scenario.screenshots).size, included, absentServerLogs });
}
assert.equal(selections.length, 51);
assert.equal(new Set(selections.map(item => item.scope)).size, 51);
verifyCurrentSource();
// Detect evidence mutation before writing any output; the accepted bytes are retained in memory.
for (const item of artifacts.values()) {
  if (item.source !== 'temporary collector supplied for review') {
    assert.equal(hash(readFileSync(resolve(root, item.source))), item.sha256, `Evidence changed while collecting: ${item.source}`);
  }
}

const manifest = {
  schema: 'yijing-learning-feedback-evidence-v1', createdAt: new Date().toISOString(),
  scopeCount: 51, observedFileCount: 31, expectedScopes, sourceSnapshot: slash(relative(root, sourcePath)),
  sourceSnapshotSha256: hash(sourceBytes), summary: slash(relative(root, summaryPath)), summarySha256: hash(summaryBytes),
  collectorSha256: hash(selfBytes), selections,
  artifacts: [...artifacts].map(([entry, item]) => ({ entry, source: item.source, bytes: item.size, sha256: item.sha256 })),
  exclusions: ['No browser profile directories or files are read or included.',
    'Only explicitly referenced successful-scope screenshots, trace, run/server logs, summary, source snapshot and collector are included.',
    'Historical failed attempts remain in their original locations; they are referenced by the summary and are not deleted.',
    'This package does not claim real-device, screen-reader, native 200% zoom or deployed AI service verification.',
    'Full validate/E2E evidence is separate; this package covers only the 51 feedback scopes.'],
};
const manifestBytes = Buffer.from(`${JSON.stringify(manifest, null, 2)}\n`);
artifacts.set('manifest.json', { bytes: manifestBytes, size: manifestBytes.length, sha256: hash(manifestBytes) });

// Minimal standard ZIP writer using DEFLATE and UTF-8 names. Explicitly reject ZIP64-sized output.
const crcTable = Array.from({ length: 256 }, (_, index) => {
  let value = index;
  for (let bit = 0; bit < 8; bit += 1) value = value & 1 ? 0xedb88320 ^ (value >>> 1) : value >>> 1;
  return value >>> 0;
});
function crc32(bytes) {
  let value = 0xffffffff;
  for (const byte of bytes) value = crcTable[(value ^ byte) & 0xff] ^ (value >>> 8);
  return (value ^ 0xffffffff) >>> 0;
}
const locals = [];
const directory = [];
const now = new Date();
const dosDate = ((now.getUTCFullYear() - 1980) << 9) | ((now.getUTCMonth() + 1) << 5) | now.getUTCDate();
const dosTime = (now.getUTCHours() << 11) | (now.getUTCMinutes() << 5) | (now.getUTCSeconds() >>> 1);
let offset = 0;
for (const [entry, { bytes }] of artifacts) {
  const name = Buffer.from(entry);
  const compressed = deflateRawSync(bytes, { level: 6 });
  assert.ok(name.length <= 0xffff && bytes.length < 0xffffffff && compressed.length < 0xffffffff && offset < 0xffffffff, 'ZIP64 is not supported.');
  const checksum = crc32(bytes);
  const local = Buffer.alloc(30);
  local.writeUInt32LE(0x04034b50, 0); local.writeUInt16LE(20, 4); local.writeUInt16LE(0x800, 6);
  local.writeUInt16LE(8, 8); local.writeUInt16LE(dosTime, 10); local.writeUInt16LE(dosDate, 12);
  local.writeUInt32LE(checksum, 14); local.writeUInt32LE(compressed.length, 18); local.writeUInt32LE(bytes.length, 22);
  local.writeUInt16LE(name.length, 26);
  const central = Buffer.alloc(46);
  central.writeUInt32LE(0x02014b50, 0); central.writeUInt16LE(20, 4); central.writeUInt16LE(20, 6);
  central.writeUInt16LE(0x800, 8); central.writeUInt16LE(8, 10); central.writeUInt16LE(dosTime, 12); central.writeUInt16LE(dosDate, 14);
  central.writeUInt32LE(checksum, 16); central.writeUInt32LE(compressed.length, 20); central.writeUInt32LE(bytes.length, 24);
  central.writeUInt16LE(name.length, 28); central.writeUInt32LE(offset, 42);
  locals.push(local, name, compressed); directory.push(central, name);
  offset += local.length + name.length + compressed.length;
}
assert.ok(artifacts.size < 0xffff && offset < 0xffffffff, 'ZIP64 is not supported.');
const centralBytes = Buffer.concat(directory);
assert.ok(offset + centralBytes.length + 22 < 0xffffffff, 'ZIP64 is not supported.');
const end = Buffer.alloc(22);
end.writeUInt32LE(0x06054b50, 0); end.writeUInt16LE(artifacts.size, 8); end.writeUInt16LE(artifacts.size, 10);
end.writeUInt32LE(centralBytes.length, 12); end.writeUInt32LE(offset, 16);
const zipBytes = Buffer.concat([...locals, centralBytes, end]);
for (const path of [outputPath, manifestPath, checksumsPath]) assert.equal(existsSync(path), false, `Refusing overwrite: ${path}`);
writeFileSync(outputPath, zipBytes, { flag: 'wx' });
writeFileSync(manifestPath, manifestBytes, { flag: 'wx' });
writeFileSync(checksumsPath, `${hash(zipBytes)}  ${basename(outputPath)}\n${hash(manifestBytes)}  ${basename(manifestPath)}\n`, { flag: 'wx' });
console.log(JSON.stringify({ zip: outputPath, manifest: manifestPath, sha256: checksumsPath,
  scopeCount: 51, artifactCount: artifacts.size, zipBytes: zipBytes.length, zipSha256: hash(zipBytes) }, null, 2));
